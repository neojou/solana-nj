---
title: Implemented Design Proposals
---

The following architectural proposals have been accepted and implemented
by the Solana team. Any designs that may be subject to future change are noted
in the specific proposal page.
Design proposals that have been accepted but not yet implemented are found in
[Accepted Proposals](../proposals/accepted-design-proposals.md).
