---
title: Running a Validator
---

This section describes how to run a Solana validator node.

There are several clusters available to connect to; see [choosing a Cluster](cli/choose-a-cluster.md) for an overview of each.
